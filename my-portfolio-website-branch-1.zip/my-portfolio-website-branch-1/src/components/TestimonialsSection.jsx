import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef, useState, useEffect } from 'react'
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react'
import profileImage from '../assets/profile.png'

const TestimonialsSection = () => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, threshold: 0.2 })
  const [currentIndex, setCurrentIndex] = useState(0)

  const testimonials = [
    {
      id: 1,
      name: 'Priya Sharma',
      position: 'Data Scientist',
      company: 'InnoData AI',
      image: '/api/placeholder/80/80',
      rating: 5,
      text: 'I was impressed with Shaurya’s Python expertise. He developed custom machine learning scripts that improved our prediction accuracy by over 20%.',
      project: 'Machine Learning Model Integration'
    },
    {
      id: 2,
      name: 'Neha Verma',
      position: 'Marketing Head',
      company: 'Growthify Marketing',
      image: '/api/placeholder/80/80',
      rating: 5,
      text: 'Shaurya created an AI-powered content generator for us. It completely transformed our marketing workflow and boosted engagement across platforms.',
      project: 'AI Content Generation Tool'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      position: 'Creative Director',
      company: 'DesignStudio Pro',
      image: '/api/placeholder/80/80',
      rating: 5,
      text: 'The web platform Shaurya built for us was sleek, fast, and completely scalable. Communication was smooth, and he delivered ahead of schedule.',
      project: 'SaaS Web Application'
    },
    {
      id: 4,
      name: 'Rohan Mehta',
      position: 'Co-Founder & CTO',
      company: 'TechVeda Innovations',
      image: '/api/placeholder/80/80',
      rating: 5,
      text: 'Shaurya built an AI-powered chatbot for our customer support system. The integration was seamless, and it reduced our response time by 60%. Truly top-notch work!',
      project: 'AI Chatbot & Automation System'
    },
    {
      id: 5,
      name: 'Annu Gupta',
      position: 'COO',
      company: 'AgroTech India',
      image: '/api/placeholder/80/80',
      rating: 5,
      text: 'The web app Shaurya developed for our precision farming system was smooth, responsive, and perfectly integrated with IoT data.',
      project: 'Precision Farming Web App'
    }
  ]

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [testimonials.length])

  const nextTestimonial = () => {
    setCurrentIndex(currentIndex === testimonials.length - 1 ? 0 : currentIndex + 1)
  }

  const prevTestimonial = () => {
    setCurrentIndex(currentIndex === 0 ? testimonials.length - 1 : currentIndex - 1)
  }

  const goToTestimonial = (index) => {
    setCurrentIndex(index)
  }

  return (
    <section id="testimonials" ref={ref} className="py-20 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Animated Background Elements */}
      <motion.div
        animate={{
          rotate: [0, 360],
          scale: [1, 1.2, 1]
        }}
        transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        className="absolute top-20 left-20 w-32 h-32 border border-purple-400/10 rounded-full"
      />
      <motion.div
        animate={{
          rotate: [360, 0],
          scale: [1.2, 1, 1.2]
        }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
        className="absolute bottom-20 right-20 w-24 h-24 border border-pink-400/10 rounded-full"
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center mb-6">
            {/* Profile Image Circle */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={isInView ? { scale: 1, opacity: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative mr-6"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-400 via-pink-500 to-purple-600 p-1"
              >
                <div className="w-16 h-16 rounded-full bg-black" />
              </motion.div>
              <motion.img
                whileHover={{ scale: 1.1 }}
                src={profileImage}
                alt="Profile"
                className="relative w-16 h-16 rounded-full object-cover border-2 border-black"
              />
            </motion.div>
            
            <h2 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-white via-purple-400 to-pink-500 bg-clip-text text-transparent">
              Client Testimonials
            </h2>
          </div>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            What clients say about working with me
          </p>
        </motion.div>

        {/* Main Testimonial Display */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          {/* Testimonial Card */}
          <div className="relative bg-gray-800/80 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-gray-700/50 overflow-hidden">
            {/* Background Gradient */}
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 to-blue-500/5" />
            
            {/* Quote Icon */}
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="absolute top-8 right-8 text-purple-400/20"
            >
              <Quote className="w-16 h-16" />
            </motion.div>

            <div className="relative z-10">
              {/* Stars */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="flex space-x-1 mb-6"
              >
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: 0.8 + i * 0.1 }}
                  >
                    <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                  </motion.div>
                ))}
              </motion.div>

              {/* Testimonial Text */}
              <motion.p
                key={currentIndex}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -30 }}
                transition={{ duration: 0.6 }}
                className="text-lg md:text-xl text-gray-300 leading-relaxed mb-8 italic"
              >
                "{testimonials[currentIndex].text}"
              </motion.p>

              {/* Client Info */}
              <motion.div
                key={`client-${currentIndex}`}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="flex items-center space-x-4"
              >
                {/* Avatar */}
                <div className="relative">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center text-black font-bold text-xl"
                  >
                    {testimonials[currentIndex].name.split(' ').map(n => n[0]).join('')}
                  </motion.div>
                </div>

                {/* Client Details */}
                <div>
                  <h4 className="text-white font-semibold text-lg">
                    {testimonials[currentIndex].name}
                  </h4>
                  <p className="text-gray-400">
                    {testimonials[currentIndex].position}
                  </p>
                  <p className="text-cyan-400 text-sm">
                    {testimonials[currentIndex].company}
                  </p>
                </div>

                {/* Project Tag */}
                <div className="ml-auto hidden md:block">
                  <span className="px-4 py-2 bg-gradient-to-r from-purple-400/20 to-pink-500/20 text-purple-400 text-sm rounded-full border border-purple-400/30">
                    {testimonials[currentIndex].project}
                  </span>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Navigation Arrows */}
          <motion.button
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 1 }}
            whileHover={{ scale: 1.1, x: -5 }}
            whileTap={{ scale: 0.9 }}
            onClick={prevTestimonial}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 p-3 bg-gray-800/80 backdrop-blur-sm text-white rounded-full border border-gray-600/50 hover:border-cyan-400/50 hover:text-cyan-400 transition-all duration-300"
          >
            <ChevronLeft className="w-6 h-6" />
          </motion.button>

          <motion.button
            initial={{ opacity: 0, x: 20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 1 }}
            whileHover={{ scale: 1.1, x: 5 }}
            whileTap={{ scale: 0.9 }}
            onClick={nextTestimonial}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 p-3 bg-gray-800/80 backdrop-blur-sm text-white rounded-full border border-gray-600/50 hover:border-cyan-400/50 hover:text-cyan-400 transition-all duration-300"
          >
            <ChevronRight className="w-6 h-6" />
          </motion.button>
        </motion.div>

        {/* Dots Indicator */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 1.2 }}
          className="flex justify-center space-x-3 mt-8"
        >
          {testimonials.map((_, index) => (
            <motion.button
              key={index}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => goToTestimonial(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex
                  ? 'bg-cyan-400 scale-125'
                  : 'bg-gray-600 hover:bg-gray-500'
              }`}
            />
          ))}
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={isInView ? { opacity: 1, scaleX: 1 } : {}}
          transition={{ duration: 0.8, delay: 1.4 }}
          className="mt-8 mx-auto max-w-md"
        >
          <div className="w-full bg-gray-700 rounded-full h-1">
            <motion.div
              key={currentIndex}
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ duration: 5, ease: 'linear' }}
              className="h-1 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
            />
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default TestimonialsSection


import { motion } from 'framer-motion'
import { ChevronDown, Github, Linkedin, Mail, Instagram } from 'lucide-react'
import Scene3D from './Scene3D'
import AnimatedText from './AnimatedText'
import profileImage from '../assets/profile.png'

const HeroSection = () => {
  const scrollToNext = () => {
    const nextSection = document.querySelector('#about')
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-900 via-black to-gray-800">
      {/* 3D Background */}
      <Scene3D className="absolute inset-0 w-full h-full" />
      
      {/* Animated Background Gradient */}
      <motion.div
        animate={{
          background: [
            'radial-gradient(circle at 20% 50%, rgba(100, 255, 218, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 80% 50%, rgba(100, 255, 218, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 50% 20%, rgba(100, 255, 218, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 50% 80%, rgba(100, 255, 218, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 20% 50%, rgba(100, 255, 218, 0.1) 0%, transparent 50%)'
          ]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-0"
      />

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        {/* Profile Image */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, delay: 0.5, type: 'spring', stiffness: 100 }}
          className="mb-8 flex justify-center"
        >
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 p-1"
            >
              <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full bg-black" />
            </motion.div>
            <motion.img
              whileHover={{ scale: 1.1 }}
              src={profileImage}
              alt="Profile"
              className="relative w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover border-4 border-black"
            />
          </div>
        </motion.div>

        {/* Main Heading */}
        <AnimatedText
          text="Shaurya Gupta"
          variant="fadeInUp"
          delay={0.8}
          className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-4 bg-gradient-to-r from-white via-purple-400 to-pink-500 bg-clip-text text-transparent"
        />

        {/* Subheading */}
        <AnimatedText
          text="AI Developer | Automation Expert | Web Builder"
          variant="fadeInUp"
          delay={1.2}
          className="text-xl sm:text-2xl lg:text-3xl text-gray-300 mb-6"
        />

        {/* Description */}
        <AnimatedText
          text="Crafting cutting-edge Tools, Automation Scripts, Websites with modern technologies"
          variant="fadeInUp"
          delay={1.6}
          className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto"
        />

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 2 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
        >
          <motion.button
            whileHover={{ 
              scale: 1.05,
              boxShadow: '0 0 30px rgba(100, 255, 218, 0.5)'
            }}
            whileTap={{ scale: 0.95 }}
            onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-3 bg-gradient-to-r from-purple-400 to-pink-500 text-black font-semibold rounded-full hover:from-purple-300 hover:to-pink-400 transition-all duration-300"
          >
            View My Work
          </motion.button>
          
          <motion.button
            whileHover={{ 
              scale: 1.05,
              borderColor: '#64ffda'
            }}
            whileTap={{ scale: 0.95 }}
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-3 border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-black transition-all duration-300"
          >
            Get In Touch
          </motion.button>
        </motion.div>

        {/* Social Links */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 2.4 }}
          className="flex justify-center space-x-6 mb-12"
        >
          {[
            { icon: Github, href: 'https://github.com/shaurya-gupta-dev', label: 'GitHub' },
            { icon: Linkedin, href: 'www.linkedin.com/in/shaurya-gupta-dev', label: 'LinkedIn' },
            { icon: Instagram, href: 'https://www.instagram.com/shaurya_codes/', label: 'Instagram' }
          ].map((social, index) => (
            <motion.a
              key={social.label}
              href={social.href}
              whileHover={{ 
                scale: 1.2, 
                color: '#a855f7',
                rotate: 360
              }}
              whileTap={{ scale: 0.9 }}
              transition={{ duration: 0.3 }}
              className="text-gray-400 hover:text-cyan-400 transition-colors duration-300"
              aria-label={social.label}
            >
              <social.icon size={24} />
            </motion.a>
          ))}
        </motion.div>

        {/* Scroll Indicator */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 2.8 }}
          onClick={scrollToNext}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-white hover:text-cyan-400 transition-colors duration-300"
          >
            <ChevronDown size={32} />
          </motion.div>
        </motion.button>
      </div>
    </section>
  )
}

export default HeroSection


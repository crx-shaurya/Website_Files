import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'

const AnimatedText = ({ text, className, delay = 0, variant = 'fadeInUp' }) => {
  const [displayText, setDisplayText] = useState('')
  const [currentIndex, setCurrentIndex] = useState(0)

  const variants = {
    fadeInUp: {
      hidden: { opacity: 0, y: 50 },
      visible: { opacity: 1, y: 0 }
    },
    slideInLeft: {
      hidden: { opacity: 0, x: -100 },
      visible: { opacity: 1, x: 0 }
    },
    slideInRight: {
      hidden: { opacity: 0, x: 100 },
      visible: { opacity: 1, x: 0 }
    },
    typewriter: {
      hidden: { opacity: 1 },
      visible: { opacity: 1 }
    },
    scale: {
      hidden: { opacity: 0, scale: 0.5 },
      visible: { opacity: 1, scale: 1 }
    }
  }

  useEffect(() => {
    if (variant === 'typewriter') {
      const timer = setTimeout(() => {
        if (currentIndex < text.length) {
          setDisplayText(text.slice(0, currentIndex + 1))
          setCurrentIndex(currentIndex + 1)
        }
      }, 100 + delay * 1000)

      return () => clearTimeout(timer)
    } else {
      setDisplayText(text)
    }
  }, [currentIndex, text, delay, variant])

  if (variant === 'typewriter') {
    return (
      <motion.div
        className={className}
        initial="hidden"
        animate="visible"
        variants={variants[variant]}
        transition={{ delay }}
      >
        {displayText}
        <motion.span
          animate={{ opacity: [1, 0] }}
          transition={{ duration: 0.8, repeat: Infinity, repeatType: 'reverse' }}
          className="inline-block w-0.5 h-6 bg-current ml-1"
        />
      </motion.div>
    )
  }

  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={variants[variant]}
      transition={{
        duration: 0.8,
        delay,
        ease: [0.25, 0.25, 0.25, 0.75]
      }}
    >
      {text}
    </motion.div>
  )
}

export default AnimatedText


import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Navigation from './Navigation';
import Footer from './Footer';
import { ExternalLink, Github, Eye } from 'lucide-react'; // Using lucide-react for consistency

const allProjects = [
  {
    id: 1,
    title: 'E-Commerce Platform',
    description: 'A modern e-commerce platform with 3D product visualization, real-time inventory, and seamless checkout experience.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/64ffda?text=E-commerce',
    technologies: ['React', 'Three.js', 'Node.js', 'MongoDB'],
    category: 'web_app',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 2,
    title: 'Portfolio Website',
    description: 'An immersive 3D portfolio website, showcasing creative work with interactive animations and smooth transitions.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/8A2BE2?text=Portfolio',
    technologies: ['React', 'Three.js', 'Framer Motion', 'Tailwind'],
    category: 'web_app',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 3,
    title: 'Mobile Banking App',
    description: 'Secure mobile banking application with biometric authentication and real-time transaction monitoring.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/FFD700?text=Mobile App',
    technologies: ['React Native', 'TypeScript', 'Firebase', 'Stripe'],
    category: 'mobile_app',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 4,
    title: 'Data Visualization Dashboard',
    description: 'Interactive dashboard for complex data visualization with real-time updates and financial reporting.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/00CED1?text=Dashboard',
    technologies: ['Vue.js', 'D3.js', 'Python', 'PostgreSQL'],
    category: 'web_app',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 5,
    title: 'AI-Powered Chatbot',
    description: 'An intelligent chatbot that uses natural language processing to understand and respond to user queries.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/FF69B4?text=Chatbot',
    technologies: ['Python', 'TensorFlow', 'Flask', 'Dialogflow'],
    category: 'ai_tool',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 6,
    title: 'Custom CLI Tool',
    description: 'A command-line interface tool for automating various development tasks, from code generation to deployment.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/FF4500?text=CLI Tool',
    technologies: ['Node.js', 'Commander.js', 'Shell Scripting'],
    category: 'script',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 7,
    title: 'Real-time Collaboration App',
    description: 'A web-based application for real-time collaborative document editing and communication.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/64ffda?text=Collab App',
    technologies: ['React', 'WebSockets', 'Node.js', 'Express'],
    category: 'web_app',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 8,
    title: 'Cross-platform Mobile Game',
    description: 'A 2D platformer game built with a custom engine, featuring a unique art style and engaging gameplay.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/8A2BE2?text=Mobile Game',
    technologies: ['Unity', 'C#', 'Mobile'],
    category: 'mobile_app',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 9,
    title: 'Automated Testing Framework',
    description: 'A custom testing framework for end-to-end testing of web applications, with a focus on performance and reliability.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/FFD700?text=Testing',
    technologies: ['JavaScript', 'Puppeteer', 'Jest'],
    category: 'script',
    liveUrl: '#',
    githubUrl: '#',
  },
  {
    id: 10,
    title: 'Machine Learning Model Deployment',
    description: 'Deployment of a machine learning model for real-time inference on edge devices, optimized for low-latency.',
    image: 'https://via.placeholder.com/400x300/0A0A0A/00CED1?text=ML Deploy',
    technologies: ['Python', 'TensorFlow Lite', 'Edge ML'],
    category: 'ai_tool',
    liveUrl: '#',
    githubUrl: '#',
  },
];

const categories = [
  { id: 'all', name: 'All Projects' },
  { id: 'web_app', name: 'Web Apps' },
  { id: 'mobile_app', name: 'Mobile Apps' },
  { id: '3d_animation', name: '3D/Animation' },
  { id: 'ai_tool', name: 'AI/ML Tools' },
  { id: 'script', name: 'Scripts' },
  { id: 'content_tool', name: 'Content Tools' },
];

const AllProjectsPage = () => {
  const [filter, setFilter] = useState('all');

  const filteredProjects = filter === 'all'
    ? allProjects
    : allProjects.filter(project => project.category === filter);

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />
      <main className="container mx-auto px-4 py-16">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-bold text-center mb-12 bg-gradient-to-r from-white via-purple-400 to-pink-500 bg-clip-text text-transparent"
        >
          All My Projects
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category, index) => (
            <motion.button
              key={category.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setFilter(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-colors duration-300 ${
                filter === category.id
                  ? 'bg-gradient-to-r from-purple-400 to-pink-500 text-black'
                  : 'bg-gray-800/50 text-gray-300 hover:bg-gray-700/50 hover:text-white border border-gray-600/50'
              }`}
            >
              {category.name}
            </motion.button>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative bg-gray-800/80 rounded-2xl overflow-hidden border border-gray-700/50 hover:border-purple-400/50 transition-all duration-300"
            >
              <div className="relative h-48 bg-gradient-to-br from-gray-700 to-gray-800 overflow-hidden">
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.6 }}
                  className="w-full h-full bg-gradient-to-br from-purple-400/20 to-pink-500/20 flex items-center justify-center"
                >
                  <Eye className="w-12 h-12 text-purple-400" />
                </motion.div>
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute inset-0 bg-black/60 flex items-center justify-center space-x-4"
                >
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-purple-400 text-black rounded-full hover:bg-purple-300 transition-colors duration-300"
                  >
                    <ExternalLink className="w-5 h-5" />
                  </a>
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-gray-700 text-white rounded-full hover:bg-gray-600 transition-colors duration-300"
                  >
                    <Github className="w-5 h-5" />
                  </a>
                </motion.div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-400 transition-colors duration-300">
                  {project.title}
                </h3>
                <p className="text-gray-400 mb-4 leading-relaxed">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-3 py-1 bg-gray-700/50 text-purple-400 text-xs rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AllProjectsPage;



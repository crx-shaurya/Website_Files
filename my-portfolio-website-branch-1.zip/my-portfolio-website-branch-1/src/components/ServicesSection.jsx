import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { Workflow, Cpu, CodeXml, Database, MessageSquareCode, Sparkles } from 'lucide-react'

const ServicesSection = () => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, threshold: 0.2 })

  const services = [
    {
      icon: Workflow,
      title: 'AI Automation & Integration',
      description: 'Automating workflows and connecting AI with everyday tools for maximum efficiency.',
      features: ['Make.com', 'Zapier', 'LangChain', 'Custom Python'],
      color: 'from-blue-400 to-cyan-400'
    },
    {
      icon: Cpu,
      title: 'Custom AI Tool Development',
      description: 'Building AI-powered solutions tailored for businesses and creators.',
      features: ['OpenAi API', 'Python', 'FastAPI', 'Streamlit'],
      color: 'from-purple-400 to-pink-400'
    },
    {
      icon: CodeXml,
      title: 'Web Development',
      description: 'Creating responsive, modern, and scalable websites with seamless UI/UX.',
      features: ['HTML', 'CSS', 'JavaScript', 'Reat & Tailwind CSS'],
      color: 'from-green-400 to-emerald-400'
    },
    {
      icon: Database,
      title: 'Data Handling & Python Development',
      description: 'Writing clean, powerful Python scripts for automation, analysis, and backend tasks.',
      features: ['Python', 'Numpy', 'Panda', 'Flask'],
      color: 'from-orange-400 to-red-400'
    },
    {
      icon: MessageSquareCode,
      title: 'AI Chatbot & API Solutions',
      description: 'Designing intelligent chatbots and integrating APIs for smart, interactive systems',
      features: ['OpenAi API', 'FstAPI', 'LangChain', 'Third party API'],
      color: 'from-indigo-400 to-purple-400'
    },
    {
      icon: Sparkles,
      title: 'AI-Powered Content Tools',
      description: 'Developing tools for content generation, rewriting, and social media automation.',
      features: ['Python', 'Node.js', 'OpenAi API', 'FastAPI'],
      color: 'from-yellow-400 to-orange-400'
    }
  ]

  return (
    <section id="services" ref={ref} className="py-20 bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, #64ffda 2px, transparent 2px),
                           radial-gradient(circle at 75% 75%, #64ffda 2px, transparent 2px)`,
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-white via-purple-400 to-pink-500 bg-clip-text text-transparent">
            What I Do
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Comprehensive digital solutions tailored to bring your vision to life
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ 
                y: -10,
                transition: { duration: 0.3 }
              }}
              className="group relative"
            >
              {/* Card Background with Gradient Border */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 to-pink-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300" />
              
              <div className="relative bg-gray-800/80 backdrop-blur-sm p-8 rounded-2xl border border-gray-700/50 group-hover:border-purple-400/50 transition-all duration-300 h-full">
                {/* Icon */}
                <motion.div
                  whileHover={{
                    rotate: 360,
                    scale: 1.1
                  }}
                  transition={{ duration: 0.6 }}
                  className={`w-16 h-16 rounded-xl flex items-center justify-center mb-6 bg-gradient-to-br from-purple-400 to-pink-500 text-black group-hover:shadow-lg group-hover:shadow-purple-400/25`}
                >
                  <service.icon className="w-8 h-8 text-black" />
                </motion.div>

                {/* Content */}
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-purple-400 transition-colors duration-300">
                  {service.title}
                </h3>
                
                <p className="text-gray-400 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features */}
                <div className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <motion.div
                      key={feature}
                      initial={{ opacity: 0, x: -20 }}
                      animate={isInView ? { opacity: 1, x: 0 } : {}}
                      transition={{ duration: 0.4, delay: (index * 0.1) + (featureIndex * 0.05) + 0.3 }}
                      className="flex items-center text-sm text-gray-300"
                    >
                      <motion.div
                        whileHover={{ scale: 1.2 }}
                        className="w-2 h-2 bg-purple-400 rounded-full mr-3 flex-shrink-0"
                      />
                      {feature}
                    </motion.div>
                  ))}
                </div>

                {/* Hover Effect Overlay */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute inset-0 bg-gradient-to-r from-purple-400/5 to-pink-500/5 rounded-2xl pointer-events-none"
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="text-center mt-16"
        >
          <p className="text-gray-400 mb-8 text-lg">
            Ready to bring your project to life?
          </p>
          <motion.button
            whileHover={{ 
              scale: 1.05,
              boxShadow: '0 0 30px rgba(100, 255, 218, 0.5)'
            }}
            whileTap={{ scale: 0.95 }}
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-gradient-to-r from-purple-400 to-pink-500 text-black font-semibold rounded-full hover:from-purple-300 hover:to-pink-400 transition-all duration-300"
          >
            Let's Work Together
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

export default ServicesSection


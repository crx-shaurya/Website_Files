import React from 'react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center px-4 relative z-10">
      <motion.h1
        initial={{ opacity: 0, y: -80 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        className="text-5xl md:text-7xl font-bold mb-6 tracking-widest text-white"
      >
        Dhruv
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 1 }}
        className="text-xl md:text-2xl text-gray-400 max-w-xl"
      >
        Building elite tools & systems. Ruthlessly.
      </motion.p>

      <motion.a
        href="#projects"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.2, duration: 0.5 }}
        className="mt-10 inline-block px-6 py-3 bg-white text-black rounded-full shadow-md hover:bg-gray-200 transition"
      >
        See My Work
      </motion.a>
    </section>
  );
};

export default Hero;
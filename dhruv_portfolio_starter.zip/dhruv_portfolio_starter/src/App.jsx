import React from 'react';
import Hero from './components/Hero';

const App = () => {
  return (
    <div className="bg-[#0d0d0d] text-white font-sans min-h-screen overflow-x-hidden">
      <Hero />
    </div>
  );
};

export default App;
import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Tool schema
export const tools = pgTable("tools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  url: text("url").notNull(),
  category: text("category").notNull(),
  icon: text("icon").notNull(), // Lucide icon name
  type: text("type").notNull(),  // editor, framework, testing, etc.
  tags: text("tags").array().notNull(), // Array of tags
});

export const insertToolSchema = createInsertSchema(tools).pick({
  name: true,
  description: true,
  url: true,
  category: true,
  icon: true,
  type: true,
  tags: true,
});

export type InsertTool = z.infer<typeof insertToolSchema>;
export type Tool = typeof tools.$inferSelect;

// Category schema
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  displayName: text("display_name").notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  displayName: true,
});

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Tag schema
export const tags = pgTable("tags", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const insertTagSchema = createInsertSchema(tags).pick({
  name: true,
});

export type InsertTag = z.infer<typeof insertTagSchema>;
export type Tag = typeof tags.$inferSelect;

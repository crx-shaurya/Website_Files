import { FC } from "react";
import { Github, Twitter, Disc } from "lucide-react";

const Footer: FC = () => {
  return (
    <footer className="border-t border-gray-800 mt-8">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="text-xs text-gray-500 mb-4 md:mb-0">
            <span className="text-primary">&lt;</span>DevToolKit
            <span className="text-primary">/&gt;</span> - Organized collection of
            developer tools for the modern hacker
          </div>
          <div className="flex space-x-4">
            <a
              href="https://github.com"
              className="text-gray-400 hover:text-primary transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Github className="h-5 w-5" />
            </a>
            <a
              href="https://twitter.com"
              className="text-gray-400 hover:text-primary transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Twitter className="h-5 w-5" />
            </a>
            <a
              href="https://discord.com"
              className="text-gray-400 hover:text-primary transition-colors"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Disc className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import { FC } from "react";
import ToolCard from "./tool-card";
import { Tool } from "@shared/schema";

interface ToolsGridProps {
  tools: Tool[];
  isLoading: boolean;
}

const ToolsGrid: FC<ToolsGridProps> = ({ tools, isLoading }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="bg-card border border-border rounded-lg h-40 animate-pulse"
          />
        ))}
      </div>
    );
  }

  if (tools.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No tools found matching your criteria</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
};

export default ToolsGrid;

import { FC, useState } from "react";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  onSearch: (query: string) => void;
  className?: string;
}

const SearchBar: FC<SearchBarProps> = ({ onSearch, className }) => {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearch(query);
  };

  return (
    <div className={cn("w-full md:w-auto flex-1 md:max-w-md relative", className)}>
      <div className="relative flex items-center">
        <span className="absolute left-3 text-gray-400 terminal-cursor">{'>'}</span>
        <input
          type="text"
          value={searchQuery}
          onChange={handleSearch}
          placeholder="search tools..."
          className="w-full bg-card border border-border focus:border-primary focus:outline-none rounded px-8 py-2 text-sm text-gray-200 font-mono"
        />
        <Search className="absolute right-3 h-4 w-4 text-gray-400" />
      </div>
    </div>
  );
};

export default SearchBar;

import React from "react";
import { cn } from "@/lib/utils";

interface CursorProps {
  className?: string;
}

export function Cursor({ className }: CursorProps) {
  return (
    <span
      className={cn("terminal-cursor text-primary animate-blink", className)}
    >
      _
    </span>
  );
}

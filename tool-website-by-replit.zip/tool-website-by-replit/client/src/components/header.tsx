import { FC } from "react";
import SearchBar from "./search-bar";

interface HeaderProps {
  onSearch: (query: string) => void;
}

const Header: FC<HeaderProps> = ({ onSearch }) => {
  return (
    <header className="container mx-auto px-4 py-6 md:py-8">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center">
          <h1 className="text-2xl md:text-3xl font-bold text-white">
            <span className="text-primary">&lt;</span>DevToolKit
            <span className="text-primary">/&gt;</span>
          </h1>
          <div className="ml-3 hidden md:block text-sm text-gray-400 border-l border-gray-700 pl-3">
            The hacker&apos;s arsenal
          </div>
        </div>

        <SearchBar onSearch={onSearch} />
      </div>
    </header>
  );
};

export default Header;

import { FC } from "react";
import { cn } from "@/lib/utils";
import { Category } from "@shared/schema";

interface CategoryFilterProps {
  categories: Category[];
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const CategoryFilter: FC<CategoryFilterProps> = ({
  categories,
  selectedCategory,
  onCategoryChange,
}) => {
  return (
    <div className="mb-8 overflow-x-auto">
      <div className="flex space-x-2 md:space-x-4 py-2 min-w-max">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onCategoryChange(category.name)}
            className={cn(
              "category-btn px-4 py-2 text-xs md:text-sm bg-card border border-border rounded-md hover:border-primary transition-colors",
              selectedCategory === category.name && "active"
            )}
          >
            {category.displayName}
          </button>
        ))}
      </div>
    </div>
  );
};

export default CategoryFilter;

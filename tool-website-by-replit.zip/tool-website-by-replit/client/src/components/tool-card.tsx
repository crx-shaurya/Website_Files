import { FC } from "react";
import { ExternalLink } from "lucide-react";
import * as Icons from "lucide-react";
import { cn } from "@/lib/utils";
import { Tool } from "@shared/schema";

interface ToolCardProps {
  tool: Tool;
  className?: string;
}

// Dynamic icon component
const DynamicIcon = ({ name }: { name: string }) => {
  const LucideIcon = (Icons as any)[
    name.charAt(0).toUpperCase() + name.slice(1).replace(/-([a-z])/g, (g) => g[1].toUpperCase())
  ];
  
  if (!LucideIcon) {
    return <Icons.Code className="text-primary text-xl" />;
  }
  
  return <LucideIcon className="text-primary text-xl" />;
};

const ToolCard: FC<ToolCardProps> = ({ tool, className }) => {
  return (
    <div 
      className={cn(
        "tool-card bg-card border border-border rounded-lg overflow-hidden hover:border-primary", 
        className
      )}
      data-category={tool.category}
    >
      <div className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center">
            <DynamicIcon name={tool.icon} />
            <h3 className="ml-2 font-medium text-white">{tool.name}</h3>
          </div>
          <div className="flex space-x-1">
            <span className="px-1.5 text-xs bg-background rounded text-gray-400">
              {tool.type}
            </span>
          </div>
        </div>
        <p className="text-xs text-gray-400 mb-3">{tool.description}</p>
        <div className="flex justify-between items-center">
          <div className="flex flex-wrap gap-1">
            {tool.tags.slice(0, 2).map((tag, index) => (
              <span
                key={index}
                className="px-1.5 py-0.5 text-xs bg-muted rounded-sm text-gray-400"
              >
                #{tag}
              </span>
            ))}
          </div>
          <a
            href={tool.url}
            className="text-xs text-secondary hover:underline flex items-center"
            target="_blank"
            rel="noopener noreferrer"
          >
            <span>Visit</span>
            <ExternalLink className="ml-1 h-3 w-3" />
          </a>
        </div>
      </div>
    </div>
  );
};

export default ToolCard;

import { FC } from "react";
import { cn } from "@/lib/utils";
import { Tag } from "@shared/schema";

interface TagFilterProps {
  tags: Tag[];
  selectedTag: string | null;
  onTagChange: (tag: string | null) => void;
}

const TagFilter: FC<TagFilterProps> = ({ tags, selectedTag, onTagChange }) => {
  const handleTagClick = (tagName: string) => {
    if (selectedTag === tagName) {
      onTagChange(null);
    } else {
      onTagChange(tagName);
    }
  };

  return (
    <div className="mb-6">
      <div className="flex flex-wrap gap-2">
        <span className="text-sm text-gray-400 my-auto">Popular tags:</span>
        {tags.map((tag) => (
          <button
            key={tag.id}
            onClick={() => handleTagClick(tag.name)}
            className={cn(
              "tag-btn px-2 py-1 text-xs bg-card border border-border rounded-md hover:border-secondary transition-colors",
              selectedTag === tag.name && "active border-secondary"
            )}
          >
            #{tag.name}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TagFilter;

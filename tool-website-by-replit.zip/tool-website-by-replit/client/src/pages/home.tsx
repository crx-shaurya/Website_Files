import { useState } from "react";
import Header from "@/components/header";
import CategoryFilter from "@/components/category-filter";
import TagFilter from "@/components/tag-filter";
import ToolsGrid from "@/components/tools-grid";
import Footer from "@/components/footer";
import { getLastUpdatedDate } from "@/lib/utils";
import { useTools } from "@/hooks/use-tools";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  const {
    tools,
    filteredTools,
    categories,
    popularTags,
    isLoading
  } = useTools({
    searchQuery,
    selectedCategory,
    selectedTag
  });

  return (
    <div className="bg-background min-h-screen">
      <Header onSearch={setSearchQuery} />
      
      <main className="container mx-auto px-4 pb-16">
        <CategoryFilter
          categories={categories}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
        />

        <TagFilter
          tags={popularTags}
          selectedTag={selectedTag}
          onTagChange={setSelectedTag}
        />

        <div className="mb-6 flex items-center justify-between">
          <div className="text-sm text-gray-400">
            <span>{filteredTools.length}</span> tools found
          </div>
          <div className="text-xs text-gray-500">
            <span className="inline-block w-3 h-3 rounded-full bg-primary animate-pulse mr-1"></span>
            Last updated: <span>{getLastUpdatedDate()}</span>
          </div>
        </div>

        <ToolsGrid tools={filteredTools} isLoading={isLoading} />

        {filteredTools.length > 0 && filteredTools.length < tools.length && (
          <div className="mt-8 text-center">
            <button 
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
                setSelectedTag(null);
              }}
              className="px-6 py-2 bg-card border border-border rounded-md hover:border-primary transition-colors"
            >
              Reset filters
            </button>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

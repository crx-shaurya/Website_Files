import { Tool } from "@shared/schema";

// This file is just for reference - we're using the API for actual data
export const toolsData: Tool[] = [
  {
    id: 1,
    name: "VSCode",
    description: "Powerful code editor with extensions for nearly any language or framework.",
    url: "https://code.visualstudio.com/",
    category: "programming",
    icon: "code",
    type: "editor",
    tags: ["web", "code"]
  },
  {
    id: 2,
    name: "Git",
    description: "Distributed version control system for tracking changes in source code.",
    url: "https://git-scm.com/",
    category: "programming",
    icon: "git-branch",
    type: "vcs",
    tags: ["cli", "devops"]
  },
  {
    id: 3,
    name: "Chrome DevTools",
    description: "Built-in developer tools for debugging, profiling, and analyzing web apps.",
    url: "https://developers.google.com/web/tools/chrome-devtools",
    category: "programming",
    icon: "bug",
    type: "debugging",
    tags: ["web", "debugging"]
  },
  {
    id: 4,
    name: "TensorFlow",
    description: "Open-source ML library for developing and training neural network models.",
    url: "https://www.tensorflow.org/",
    category: "ai",
    icon: "brain",
    type: "framework",
    tags: ["ml", "python"]
  },
  {
    id: 5,
    name: "Hugging Face",
    description: "Platform with ready-to-use NLP models and libraries for building AI apps.",
    url: "https://huggingface.co/",
    category: "ai",
    icon: "message-square",
    type: "platform",
    tags: ["nlp", "ai"]
  },
  {
    id: 6,
    name: "Wireshark",
    description: "Network protocol analyzer for monitoring and troubleshooting network traffic.",
    url: "https://www.wireshark.org/",
    category: "security",
    icon: "wifi",
    type: "security",
    tags: ["network", "security"]
  },
  {
    id: 7,
    name: "Metasploit",
    description: "Advanced open-source framework for developing, testing, and executing exploits.",
    url: "https://www.metasploit.com/",
    category: "security",
    icon: "shield",
    type: "penetration",
    tags: ["hacking", "pentest"]
  },
  {
    id: 8,
    name: "Nmap",
    description: "Network discovery and security auditing utility for scanning and mapping networks.",
    url: "https://nmap.org/",
    category: "security",
    icon: "scan",
    type: "scanning",
    tags: ["network", "security"]
  },
  {
    id: 9,
    name: "Docker",
    description: "Platform for developing, shipping, and running applications in isolated containers.",
    url: "https://www.docker.com/",
    category: "devops",
    icon: "box",
    type: "container",
    tags: ["devops", "cloud"]
  },
  {
    id: 10,
    name: "Kubernetes",
    description: "Container orchestration system for automating deployment and scaling of applications.",
    url: "https://kubernetes.io/",
    category: "devops",
    icon: "layers",
    type: "orchestration",
    tags: ["devops", "cloud"]
  },
  {
    id: 11,
    name: "Postman",
    description: "API development environment for testing, documenting and sharing APIs.",
    url: "https://www.postman.com/",
    category: "programming",
    icon: "send",
    type: "api",
    tags: ["testing", "api"]
  }
];

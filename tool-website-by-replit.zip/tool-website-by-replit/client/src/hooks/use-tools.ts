import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Tool, Category, Tag } from "@shared/schema";

interface UseToolsProps {
  searchQuery: string;
  selectedCategory: string;
  selectedTag: string | null;
}

export function useTools({ searchQuery, selectedCategory, selectedTag }: UseToolsProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [popularTags, setPopularTags] = useState<Tag[]>([]);

  // Fetch tools from API
  const {
    data: tools = [],
    isLoading: isToolsLoading,
  } = useQuery<Tool[]>({
    queryKey: ["/api/tools"],
  });

  // Fetch categories from API
  const { data: categoriesData = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Fetch tags from API
  const { data: tagsData = [] } = useQuery<Tag[]>({
    queryKey: ["/api/tags"],
  });

  // Set categories and tags when data is loaded
  useEffect(() => {
    if (categoriesData.length > 0) {
      setCategories(categoriesData);
    }
    
    if (tagsData.length > 0) {
      // Only include the first 5 tags as "popular"
      setPopularTags(tagsData.slice(0, 5));
    }
  }, [categoriesData, tagsData]);

  // Filter tools based on search query, category, and tag
  const filteredTools = useMemo(() => {
    return tools.filter((tool) => {
      const matchesSearch =
        searchQuery === "" ||
        tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tool.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tool.tags.some((tag) =>
          tag.toLowerCase().includes(searchQuery.toLowerCase())
        );

      const matchesCategory =
        selectedCategory === "all" || tool.category === selectedCategory;

      const matchesTag =
        !selectedTag || tool.tags.includes(selectedTag);

      return matchesSearch && matchesCategory && matchesTag;
    });
  }, [tools, searchQuery, selectedCategory, selectedTag]);

  return {
    tools,
    filteredTools,
    categories,
    popularTags,
    isLoading: isToolsLoading,
  };
}

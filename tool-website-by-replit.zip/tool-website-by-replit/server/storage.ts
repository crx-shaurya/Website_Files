import { 
  tools, 
  categories, 
  tags,
  type Tool, 
  type InsertTool, 
  type Category, 
  type InsertCategory,
  type Tag,
  type InsertTag
} from "@shared/schema";

export interface IStorage {
  getAllTools(): Promise<Tool[]>;
  getToolsByCategory(category: string): Promise<Tool[]>;
  getToolsByTag(tag: string): Promise<Tool[]>;
  searchTools(query: string): Promise<Tool[]>;
  getAllCategories(): Promise<Category[]>;
  getAllTags(): Promise<Tag[]>;
}

export class MemStorage implements IStorage {
  private tools: Map<number, Tool>;
  private categories: Map<number, Category>;
  private tags: Map<number, Tag>;
  private toolsCurrentId: number;
  private categoriesCurrentId: number;
  private tagsCurrentId: number;

  constructor() {
    this.tools = new Map();
    this.categories = new Map();
    this.tags = new Map();
    this.toolsCurrentId = 1;
    this.categoriesCurrentId = 1;
    this.tagsCurrentId = 1;
    
    // Initialize with default data
    this.initializeData();
  }

  async getAllTools(): Promise<Tool[]> {
    return Array.from(this.tools.values());
  }

  async getToolsByCategory(category: string): Promise<Tool[]> {
    return Array.from(this.tools.values()).filter(
      (tool) => tool.category === category
    );
  }

  async getToolsByTag(tag: string): Promise<Tool[]> {
    return Array.from(this.tools.values()).filter(
      (tool) => tool.tags.includes(tag)
    );
  }

  async searchTools(query: string): Promise<Tool[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.tools.values()).filter(
      (tool) => 
        tool.name.toLowerCase().includes(lowerQuery) || 
        tool.description.toLowerCase().includes(lowerQuery) ||
        tool.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
    );
  }

  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getAllTags(): Promise<Tag[]> {
    return Array.from(this.tags.values());
  }

  private initializeData() {
    // Initialize categories
    const categoryData: InsertCategory[] = [
      { name: "all", displayName: "All Tools" },
      { name: "programming", displayName: "Programming" },
      { name: "ai", displayName: "AI Development" },
      { name: "security", displayName: "Security/Hacking" },
      { name: "devops", displayName: "DevOps" }
    ];
    
    categoryData.forEach(category => {
      const id = this.categoriesCurrentId++;
      this.categories.set(id, { ...category, id });
    });

    // Initialize tags
    const tagData: InsertTag[] = [
      { name: "web" },
      { name: "cli" },
      { name: "debugging" },
      { name: "framework" },
      { name: "testing" },
      { name: "network" },
      { name: "security" },
      { name: "cloud" },
      { name: "api" },
      { name: "code" },
      { name: "devops" },
      { name: "ml" },
      { name: "python" },
      { name: "nlp" },
      { name: "ai" },
      { name: "hacking" },
      { name: "pentest" }
    ];

    tagData.forEach(tag => {
      const id = this.tagsCurrentId++;
      this.tags.set(id, { ...tag, id });
    });

    // Initialize tools
    const toolsData: InsertTool[] = [
      {
        name: "VSCode",
        description: "Powerful code editor with extensions for nearly any language or framework.",
        url: "https://code.visualstudio.com/",
        category: "programming",
        icon: "code",
        type: "editor",
        tags: ["web", "code"]
      },
      {
        name: "Git",
        description: "Distributed version control system for tracking changes in source code.",
        url: "https://git-scm.com/",
        category: "programming",
        icon: "git-branch",
        type: "vcs",
        tags: ["cli", "devops"]
      },
      {
        name: "Chrome DevTools",
        description: "Built-in developer tools for debugging, profiling, and analyzing web apps.",
        url: "https://developers.google.com/web/tools/chrome-devtools",
        category: "programming",
        icon: "bug",
        type: "debugging",
        tags: ["web", "debugging"]
      },
      {
        name: "TensorFlow",
        description: "Open-source ML library for developing and training neural network models.",
        url: "https://www.tensorflow.org/",
        category: "ai",
        icon: "brain",
        type: "framework",
        tags: ["ml", "python"]
      },
      {
        name: "Hugging Face",
        description: "Platform with ready-to-use NLP models and libraries for building AI apps.",
        url: "https://huggingface.co/",
        category: "ai",
        icon: "message-square",
        type: "platform",
        tags: ["nlp", "ai"]
      },
      {
        name: "Wireshark",
        description: "Network protocol analyzer for monitoring and troubleshooting network traffic.",
        url: "https://www.wireshark.org/",
        category: "security",
        icon: "wifi",
        type: "security",
        tags: ["network", "security"]
      },
      {
        name: "Metasploit",
        description: "Advanced open-source framework for developing, testing, and executing exploits.",
        url: "https://www.metasploit.com/",
        category: "security",
        icon: "shield",
        type: "penetration",
        tags: ["hacking", "pentest"]
      },
      {
        name: "Nmap",
        description: "Network discovery and security auditing utility for scanning and mapping networks.",
        url: "https://nmap.org/",
        category: "security",
        icon: "scan",
        type: "scanning",
        tags: ["network", "security"]
      },
      {
        name: "Docker",
        description: "Platform for developing, shipping, and running applications in isolated containers.",
        url: "https://www.docker.com/",
        category: "devops",
        icon: "box",
        type: "container",
        tags: ["devops", "cloud"]
      },
      {
        name: "Kubernetes",
        description: "Container orchestration system for automating deployment and scaling of applications.",
        url: "https://kubernetes.io/",
        category: "devops",
        icon: "layers",
        type: "orchestration",
        tags: ["devops", "cloud"]
      },
      {
        name: "Postman",
        description: "API development environment for testing, documenting and sharing APIs.",
        url: "https://www.postman.com/",
        category: "programming",
        icon: "send",
        type: "api",
        tags: ["testing", "api"]
      },
      {
        name: "PyTorch",
        description: "Open source machine learning framework for deep neural networks.",
        url: "https://pytorch.org/",
        category: "ai",
        icon: "zap",
        type: "framework",
        tags: ["ml", "python", "ai"]
      },
      {
        name: "Burp Suite",
        description: "Web vulnerability scanner and proxy tool for security testing.",
        url: "https://portswigger.net/burp",
        category: "security",
        icon: "shield-alert",
        type: "security",
        tags: ["security", "web", "pentest"]
      },
      {
        name: "Jenkins",
        description: "Open source automation server for building, testing, and deploying code.",
        url: "https://www.jenkins.io/",
        category: "devops",
        icon: "repeat",
        type: "ci/cd",
        tags: ["devops", "automation"]
      },
      {
        name: "GitHub",
        description: "Code hosting platform for version control and collaboration.",
        url: "https://github.com/",
        category: "programming",
        icon: "github",
        type: "platform",
        tags: ["code", "collaboration"]
      },
      {
        name: "Jupyter Notebook",
        description: "Web application for creating and sharing documents with live code.",
        url: "https://jupyter.org/",
        category: "ai",
        icon: "book-open",
        type: "tool",
        tags: ["python", "ml", "data"]
      },
      {
        name: "Kali Linux",
        description: "Advanced penetration testing and security auditing Linux distribution.",
        url: "https://www.kali.org/",
        category: "security",
        icon: "terminal",
        type: "operating-system",
        tags: ["security", "hacking", "pentest"]
      },
      {
        name: "Terraform",
        description: "Infrastructure as code software tool for building and managing cloud infrastructure.",
        url: "https://www.terraform.io/",
        category: "devops",
        icon: "settings",
        type: "infrastructure",
        tags: ["devops", "cloud", "automation"]
      }
    ];

    toolsData.forEach(tool => {
      const id = this.toolsCurrentId++;
      this.tools.set(id, { ...tool, id });
    });
  }
}

export const storage = new MemStorage();

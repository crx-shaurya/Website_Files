import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route to get all tools
  app.get('/api/tools', async (req, res) => {
    try {
      const tools = await storage.getAllTools();
      res.json(tools);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch tools' });
    }
  });

  // API route to get tools by category
  app.get('/api/tools/category/:category', async (req, res) => {
    try {
      const { category } = req.params;
      const tools = await storage.getToolsByCategory(category);
      res.json(tools);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch tools by category' });
    }
  });

  // API route to get tools by tag
  app.get('/api/tools/tag/:tag', async (req, res) => {
    try {
      const { tag } = req.params;
      const tools = await storage.getToolsByTag(tag);
      res.json(tools);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch tools by tag' });
    }
  });

  // API route to search tools
  app.get('/api/tools/search', async (req, res) => {
    try {
      const { query } = req.query;
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: 'Search query is required' });
      }
      const tools = await storage.searchTools(query);
      res.json(tools);
    } catch (error) {
      res.status(500).json({ message: 'Failed to search tools' });
    }
  });

  // API route to get all categories
  app.get('/api/categories', async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch categories' });
    }
  });

  // API route to get all tags
  app.get('/api/tags', async (req, res) => {
    try {
      const tags = await storage.getAllTags();
      res.json(tags);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch tags' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

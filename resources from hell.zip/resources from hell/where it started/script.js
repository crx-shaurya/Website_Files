// Lightning Effect
const lightningEffect = document.querySelector('.lightning-effect');

setInterval(() => {
    lightningEffect.style.opacity = Math.random() > 0.7 ? '1' : '0';
}, 200); // Random lightning flashes every 200ms

// Glitch Animation for Header
const glitchHeader = document.querySelector('.glitch');
function addGlitch() {
    glitchHeader.classList.add('glitch-active');
    setTimeout(() => glitchHeader.classList.remove('glitch-active'), 1000);
}
setInterval(addGlitch, 3000); // Glitch effect every 3 seconds

// Hacker Text Typing
const hackerText = document.querySelector('.hacker-text');
const text = "Your central hub for all resources in one place.";
let index = 0;

function typeText() {
    if (index < text.length) {
        hackerText.textContent += text[index];
        index++;
        setTimeout(typeText, 100); // Speed of typing
    }
}

setTimeout(typeText, 1000); // Delay before typing starts
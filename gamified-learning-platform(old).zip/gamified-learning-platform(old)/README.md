# EduQuest - Gamified Learning Platform

## 🎮 Overview
EduQuest is a revolutionary gamified learning environment designed for students from grades 6-12. The platform transforms traditional education into an addictive, game-like experience that motivates students to learn continuously through interactive elements, achievements, and social features.

## 🚀 Features

### 🎯 Gamification Elements
- **XP System**: Students earn experience points for completing tasks and activities
- **Level Progression**: Advance through levels as you master different subjects
- **Achievement Badges**: Collect prestigious badges for various accomplishments
- **Daily Streaks**: Build learning habits with streak counters
- **Leaderboards**: Compete with friends and classmates

### 🤖 Interactive Mascot
- **Animated Guide**: Friendly mascot with animated hands and legs
- **Interactive Messages**: Click the mascot for motivational messages
- **Learning Assistant**: Helps new students navigate the platform

### 📚 Core Subjects
- **Mathematics**: Algebra, Geometry, Trigonometry, and more
- **Science**: Physics, Chemistry, Biology concepts
- **English**: Grammar, Literature, Creative Writing

### 🎵 Sound Effects
- Achievement sounds for earning badges and XP
- Navigation click sounds
- Mascot interaction audio
- Level up celebrations

### 📱 Modern Design
- Responsive design for desktop and mobile
- Video game-inspired UI/UX
- Smooth animations and transitions
- Modern gradient backgrounds

## 🛠️ Technology Stack
- **Frontend**: React 18 with Vite
- **Styling**: Tailwind CSS + Custom CSS
- **Animations**: Framer Motion
- **Icons**: Lucide React
- **UI Components**: Custom component library
- **Deployment**: Vercel-ready

## 📁 Project Structure
```
gamified-learning-platform/
├── src/
│   ├── components/
│   │   ├── LandingPage.jsx      # Main landing page
│   │   ├── LearningPage.jsx     # Student dashboard
│   │   ├── AuthPage.jsx         # Login/Registration
│   │   └── GameElements.jsx     # Gamification components
│   ├── hooks/
│   │   └── useSound.js          # Sound effects hook
│   ├── assets/
│   │   ├── mascot1.jpg          # Original mascot
│   │   ├── mascot_animated_*.png # Animated frames
│   │   ├── badge_*.png          # Achievement badges
│   │   ├── *_icon.png           # UI icons
│   │   └── *.wav                # Sound effects
│   ├── App.jsx                  # Main app component
│   └── App.css                  # Global styles
├── package.json
└── README.md
```

## 🎨 Assets Included
- **Mascot Animations**: 4 frames for smooth animation
- **Achievement Badges**: Math Master, Science Explorer, English Writer
- **UI Icons**: XP lightning bolt, streak fire icon
- **Sound Effects**: Achievement, navigation, mascot interaction, level up

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation
1. Clone or extract the project files
2. Navigate to the project directory:
   ```bash
   cd gamified-learning-platform
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Open http://localhost:5173 in your browser

### Building for Production
```bash
npm run build
```

### Deployment to Vercel
1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow the prompts to deploy

## 🎮 How to Use

### For Students
1. **Register**: Create an account with your grade level
2. **Explore Subjects**: Choose from Math, Science, or English
3. **Earn XP**: Complete activities to gain experience points
4. **Collect Badges**: Unlock achievements for various milestones
5. **Build Streaks**: Learn daily to maintain your streak
6. **Compete**: Check leaderboards to see your ranking

### For Teachers
- Assign badges to students for completed work
- Monitor student progress through XP and levels
- Use the platform to gamify traditional assignments

## 🎯 Hackathon Presentation Features
- **Landing Page**: Engaging introduction with animated mascot
- **Registration System**: Complete user onboarding flow
- **Learning Dashboard**: Full-featured student interface
- **Gamification**: Working XP, badges, streaks, and leaderboards
- **Responsive Design**: Works on all devices
- **Sound Effects**: Immersive audio feedback

## 🔧 Customization
- Modify colors in `App.css` and component files
- Add new subjects by updating the subjects array
- Create additional badges by adding new image assets
- Extend gamification with new achievement types

## 📈 Future Enhancements
- Real-time multiplayer challenges
- AI-powered personalized learning paths
- Advanced analytics dashboard
- Mobile app development
- Integration with school management systems

## 🏆 Awards & Recognition
Built for government hackathon presentation - showcasing innovative approaches to educational technology and student engagement.

## 📞 Support
For questions or support, please contact the development team.

---
**EduQuest** - Making Learning Addictive! 🎮📚


import { useCallback } from 'react';

// Import sound files
import achievementSound from '../assets/achievement_sound.wav';
import navigationSound from '../assets/navigation_sound.wav';
import mascotInteractionSound from '../assets/mascot_interaction_sound.wav';
import levelUpSound from '../assets/level_up_sound.wav';
import badgeEarnedSound from '../assets/badge_earned_sound.wav';

const useSound = () => {
  const playSound = useCallback((soundType) => {
    let audioSrc;
    let audio;

    // Stop any currently playing sound of the same type to prevent overlap
    if (window.currentAudio && window.currentAudio.soundType === soundType) {
      window.currentAudio.audio.pause();
      window.currentAudio.audio.currentTime = 0; // Reset to start
    }
    
    switch (soundType) {
      case 'achievement':
        audioSrc = achievementSound;
        break;
      case 'navigation':
        audioSrc = navigationSound;
        break;
      case 'mascot':
        audioSrc = mascotInteractionSound;
        break;
      case 'levelUp':
        audioSrc = levelUpSound;
        break;
      case 'badgeEarned':
        audioSrc = badgeEarnedSound;
        break;
      default:
        return;
    }
    
    try {
      audio = new Audio(audioSrc);
      audio.volume = 0.3; // Set volume to 30%
      audio.play().catch(error => {
        console.log('Audio play failed:', error);
      });
      // Store the currently playing audio to manage overlap
      window.currentAudio = { audio, soundType };
    } catch (error) {
      console.log('Audio creation failed:', error);
    }
  }, []);

  return { playSound };
};

export default useSound;


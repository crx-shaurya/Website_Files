import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Trophy, Star, Zap, Award, Flame, Crown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import useSound from '../hooks/useSound.js';

// XP Counter Component
export const XPCounter = ({ xp, animate = false }) => {
  const [displayXP, setDisplayXP] = useState(xp);
  
  useEffect(() => {
    if (animate && displayXP !== xp) {
      const increment = Math.ceil((xp - displayXP) / 20);
      const timer = setInterval(() => {
        setDisplayXP(prev => {
          if (prev >= xp) {
            clearInterval(timer);
            return xp;
          }
          return prev + increment;
        });
      }, 50);
      return () => clearInterval(timer);
    }
  }, [xp, animate, displayXP]);

  return (
    <div className="flex items-center space-x-2 bg-yellow-100 px-4 py-2 rounded-full">
      <Zap className="h-5 w-5 text-yellow-600" />
      <span className="font-bold text-yellow-800">{displayXP.toLocaleString()} XP</span>
    </div>
  );
};

// Level Badge Component
export const LevelBadge = ({ level }) => {
  return (
    <Badge className="bg-gradient-to-r from-teal-500 to-orange-500 text-white">
      <Crown className="w-3 h-3 mr-1" />
      Level {level}
    </Badge>
  );
};

// Streak Counter Component
export const StreakCounter = ({ streak }) => {
  return (
    <div className="flex items-center space-x-2 bg-orange-100 px-4 py-2 rounded-full">
      <Flame className="h-5 w-5 text-orange-600" />
      <span className="font-bold text-orange-800">{streak} days</span>
    </div>
  );
};

// Achievement Notification Component
export const AchievementNotification = ({ achievement, onClose }) => {
  const { playSound } = useSound();
  
  useEffect(() => {
    if (achievement) {
      playSound('achievement');
      const timer = setTimeout(onClose, 3000);
      return () => clearTimeout(timer);
    }
  }, [achievement, onClose, playSound]);

  return (
    <AnimatePresence>
      {achievement && (
        <motion.div
          initial={{ opacity: 0, y: -100, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -100, scale: 0.8 }}
          className="fixed top-4 right-4 z-50 bg-gradient-to-r from-yellow-400 to-orange-500 text-white p-6 rounded-xl shadow-2xl max-w-sm"
        >
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <Trophy className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg">Achievement Unlocked!</h3>
              <p className="text-sm opacity-90">{achievement.title}</p>
              <p className="text-xs opacity-75">{achievement.description}</p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// Progress Ring Component
export const ProgressRing = ({ progress, size = 120, strokeWidth = 8 }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const strokeDasharray = `${circumference} ${circumference}`;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg
        className="transform -rotate-90"
        width={size}
        height={size}
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          className="text-gray-200"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="text-teal-500 transition-all duration-500 ease-in-out"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-2xl font-bold text-navy-900">{Math.round(progress)}%</span>
      </div>
    </div>
  );
};

// Badge Collection Component
export const BadgeCollection = ({ badges, maxDisplay = 3 }) => {
  const displayBadges = badges.slice(0, maxDisplay);
  const remainingCount = badges.length - maxDisplay;

  return (
    <div className="flex items-center space-x-2">
      {displayBadges.map((badge, index) => (
        <motion.div
          key={index}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: index * 0.1 }}
          className="relative group"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:scale-110 transition-transform">
            <Award className="h-5 w-5 text-white" />
          </div>
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            {badge}
          </div>
        </motion.div>
      ))}
      {remainingCount > 0 && (
        <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-sm font-semibold text-gray-600">
          +{remainingCount}
        </div>
      )}
    </div>
  );
};

// Animated Progress Bar Component
export const AnimatedProgressBar = ({ value, max, label, color = "teal" }) => {
  const percentage = (value / max) * 100;
  
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="text-gray-600">{label}</span>
        <span className="font-semibold text-navy-900">{value}/{max}</span>
      </div>
      <div className="relative">
        <Progress value={percentage} className="h-3" />
        <motion.div
          className={`absolute top-0 left-0 h-3 bg-gradient-to-r from-${color}-400 to-${color}-600 rounded-full`}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </div>
    </div>
  );
};

// Leaderboard Position Component
export const LeaderboardPosition = ({ rank, name, xp, isCurrentUser = false }) => {
  const getRankColor = (rank) => {
    switch (rank) {
      case 1: return 'bg-yellow-500 text-white';
      case 2: return 'bg-gray-400 text-white';
      case 3: return 'bg-orange-500 text-white';
      default: return 'bg-gray-200 text-gray-700';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: rank * 0.1 }}
      className={`flex items-center justify-between p-3 rounded-lg ${
        isCurrentUser ? 'bg-teal-50 border-2 border-teal-200' : 'bg-gray-50'
      }`}
    >
      <div className="flex items-center space-x-3">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${getRankColor(rank)}`}>
          {rank}
        </div>
        <div>
          <p className={`font-semibold text-sm ${isCurrentUser ? 'text-teal-700' : ''}`}>
            {name}
          </p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-semibold text-sm">{xp.toLocaleString()}</p>
        <p className="text-xs text-gray-600">XP</p>
      </div>
    </motion.div>
  );
};



// XP Gain Effect Component
export const XPGainEffect = ({ show, amount, position = { x: 0, y: 0 } }) => {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    if (show) {
      const newParticles = Array.from({ length: 5 }).map((_, i) => ({
        id: Math.random(),
        x: position.x + (Math.random() - 0.5) * 20,
        y: position.y + (Math.random() - 0.5) * 20,
        vx: (Math.random() - 0.5) * 5,
        vy: (Math.random() - 1) * 5,
        opacity: 1,
        scale: 1,
      }));
      setParticles(newParticles);

      const timer = setInterval(() => {
        setParticles(prevParticles => {
          const updatedParticles = prevParticles.map(p => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy,
            vy: p.vy + 0.1, // Gravity effect
            opacity: p.opacity - 0.03,
            scale: p.scale * 0.98,
          })).filter(p => p.opacity > 0);

          if (updatedParticles.length === 0) {
            clearInterval(timer);
          }
          return updatedParticles;
        });
      }, 50);

      return () => clearInterval(timer);
    } else {
      setParticles([]);
    }
  }, [show, amount, position]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {particles.map(p => (
        <motion.div
          key={p.id}
          initial={{ x: p.x, y: p.y, opacity: 1, scale: 1 }}
          animate={{ x: p.x, y: p.y, opacity: p.opacity, scale: p.scale }}
          transition={{ duration: 0.05, ease: "linear" }}
          className="absolute text-yellow-500 font-bold text-lg"
          style={{
            left: p.x,
            top: p.y,
            opacity: p.opacity,
            transform: `translate(-50%, -50%) scale(${p.scale})`,
            textShadow: '0 0 5px rgba(255,255,0,0.5)'
          }}
        >
          +{amount} XP
        </motion.div>
      ))}
    </div>
  );
};


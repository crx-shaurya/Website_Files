import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Trophy, Star, Zap, BookOpen, Calculator, Microscope, PenTool, Users, Target, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import useSound from '../hooks/useSound.js';
import mascotFrame1 from '../assets/mascot1.jpg';
import mascotFrame2 from '../assets/mascot_animated_frame1.png';
import mascotFrame3 from '../assets/mascot_animated_frame2.png';
import mascotFrame4 from '../assets/mascot_animated_frame3.png';

const LandingPage = ({ onNavigate }) => {
  const [currentMascotFrame, setCurrentMascotFrame] = useState(0);
  const { playSound } = useSound();
  const mascotFrames = [mascotFrame1, mascotFrame2, mascotFrame3, mascotFrame4];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMascotFrame((prev) => (prev + 1) % mascotFrames.length);
    }, 800);
    return () => clearInterval(interval);
  }, []);

  const handleNavigation = (page) => {
    playSound('navigation');
    onNavigate(page);
  };

  const subjects = [
    { name: 'Mathematics', icon: Calculator, color: 'bg-blue-500', progress: 75 },
    { name: 'Science', icon: Microscope, color: 'bg-green-500', progress: 60 },
    { name: 'English', icon: PenTool, color: 'bg-purple-500', progress: 85 }
  ];

  const features = [
    { icon: Trophy, title: 'Earn Badges', description: 'Collect achievements as you master new skills' },
    { icon: Zap, title: 'XP Points', description: 'Gain experience points for every completed task' },
    { icon: Target, title: 'Daily Streaks', description: 'Build learning habits with daily challenges' },
    { icon: Users, title: 'Compete', description: 'Challenge friends on leaderboards' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-blue-50 to-teal-100">
      {/* Hero Section */}
      <section className="relative overflow-hidden px-6 py-20">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl lg:text-6xl font-bold text-navy-900 mb-6 leading-tight">
                Level Up Your
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-500 to-orange-500">
                  {' '}Learning{' '}
                </span>
                Adventure!
              </h1>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                Join thousands of students on an epic educational journey. Earn XP, collect badges, 
                and master Math, Science, and English through gamified learning experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                  onClick={() => handleNavigation('register')}
                >
                  <Star className="mr-2 h-5 w-5" />
                  Start Your Quest
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="border-2 border-teal-500 text-teal-600 hover:bg-teal-50 px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300"
                  onClick={() => handleNavigation('login')}
                >
                  Continue Journey
                </Button>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="flex justify-center"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-400 to-orange-400 rounded-full blur-3xl opacity-30 animate-pulse"></div>
                <img 
                  src={mascotFrames[currentMascotFrame]} 
                  alt="EduQuest Mascot" 
                  className="relative z-10 w-80 h-80 object-contain drop-shadow-2xl"
                />
                <motion.div
                  className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full font-bold text-sm shadow-lg"
                  animate={{ y: [-5, 5, -5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  +100 XP
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-navy-900 mb-4">
              Why Students Love EduQuest
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Transform your learning experience with game-like features that make education addictive and fun
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-2 hover:border-teal-200">
                  <CardHeader className="text-center">
                    <div className="mx-auto w-16 h-16 bg-gradient-to-br from-teal-500 to-orange-500 rounded-full flex items-center justify-center mb-4">
                      <feature.icon className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-xl font-bold text-navy-900">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-center text-gray-600 text-base">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-20 px-6 bg-white/50">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-navy-900 mb-4">
              Master Three Core Subjects
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Progress through carefully designed curricula for grades 6-12
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {subjects.map((subject, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-2 hover:border-teal-200">
                  <CardHeader className="text-center">
                    <div className={`mx-auto w-20 h-20 ${subject.color} rounded-full flex items-center justify-center mb-4 shadow-lg`}>
                      <subject.icon className="h-10 w-10 text-white" />
                    </div>
                    <CardTitle className="text-2xl font-bold text-navy-900">{subject.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Progress</span>
                        <span className="font-semibold text-navy-900">{subject.progress}%</span>
                      </div>
                      <Progress value={subject.progress} className="h-3" />
                    </div>
                    <div className="flex justify-center space-x-2">
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                        <Award className="w-3 h-3 mr-1" />
                        5 Badges
                      </Badge>
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        Level {Math.floor(subject.progress / 20) + 1}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-gradient-to-r from-teal-500 to-orange-500 rounded-3xl p-12 text-white shadow-2xl"
          >
            <h2 className="text-4xl font-bold mb-6">
              Ready to Begin Your Learning Adventure?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of students who are already leveling up their education
            </p>
            <Button 
              size="lg"
              className="bg-white text-teal-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => handleNavigation('register')}
            >
              <BookOpen className="mr-2 h-5 w-5" />
              Start Learning Now
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;


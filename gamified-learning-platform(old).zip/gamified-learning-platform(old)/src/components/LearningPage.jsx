import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx';
import { 
  Trophy, Star, Zap, BookOpen, Calculator, Microscope, PenTool, 
  Users, Target, Award, Flame, User, Settings, LogOut, 
  Play, ChevronRight, Crown, Medal
} from 'lucide-react';
import { motion } from 'framer-motion';
import useSound from '../hooks/useSound.js';
import { XPCounter, LevelBadge, StreakCounter, AchievementNotification, BadgeCollection, LeaderboardPosition, XPGainEffect } from './GameElements.jsx';
import mascotFrame1 from '../assets/mascot1.jpg';
import mascotFrame2 from '../assets/mascot_animated_frame1.png';
import mascotFrame3 from '../assets/mascot_animated_frame2.png';
import mascotFrame4 from '../assets/mascot_animated_frame3.png';

const LearningPage = ({ onNavigate, user }) => {
  const [currentMascotFrame, setCurrentMascotFrame] = useState(0);
  const [xpPoints, setXpPoints] = useState(2450);
  const [currentLevel, setCurrentLevel] = useState(8);
  const [streak, setStreak] = useState(12);
  const [mascotMessage, setMascotMessage] = useState("Welcome back! Ready to continue your learning adventure?");
  const [achievement, setAchievement] = useState(null);
  const [showXPGain, setShowXPGain] = useState(false);
  const { playSound } = useSound();

  const mascotFrames = [mascotFrame1, mascotFrame2, mascotFrame3, mascotFrame4];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMascotFrame((prev) => (prev + 1) % mascotFrames.length);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleNavigation = (page) => {
    playSound('navigation');
    onNavigate(page);
  };

  const subjects = [
    { 
      name: 'Mathematics', 
      icon: Calculator, 
      color: 'bg-blue-500', 
      progress: 75,
      level: 6,
      xp: 1200,
      nextLevelXp: 1500,
      badges: ['Algebra Master', 'Geometry Pro', 'Problem Solver'],
      activities: ['Quadratic Equations', 'Trigonometry Basics', 'Statistics']
    },
    { 
      name: 'Science', 
      icon: Microscope, 
      color: 'bg-green-500', 
      progress: 60,
      level: 5,
      xp: 950,
      nextLevelXp: 1200,
      badges: ['Lab Expert', 'Physics Wizard', 'Chemistry Star'],
      activities: ['Chemical Reactions', 'Force & Motion', 'Cell Biology']
    },
    { 
      name: 'English', 
      icon: PenTool, 
      color: 'bg-purple-500', 
      progress: 85,
      level: 7,
      xp: 1400,
      nextLevelXp: 1600,
      badges: ['Grammar Guru', 'Essay Expert', 'Literature Lover'],
      activities: ['Creative Writing', 'Poetry Analysis', 'Debate Skills']
    }
  ];

  const recentAchievements = [
    { title: 'Streak Master', description: '10 days in a row!', icon: Flame, color: 'text-orange-500' },
    { title: 'Math Wizard', description: 'Completed Algebra chapter', icon: Calculator, color: 'text-blue-500' },
    { title: 'Science Explorer', description: 'Discovered 5 new concepts', icon: Microscope, color: 'text-green-500' }
  ];

  const leaderboard = [
    { name: 'Alex Chen', xp: 3200, level: 12, rank: 1 },
    { name: 'Sarah Johnson', xp: 2800, level: 10, rank: 2 },
    { name: 'You', xp: 2450, level: 8, rank: 3 },
    { name: 'Mike Davis', xp: 2100, level: 9, rank: 4 },
    { name: 'Emma Wilson', xp: 1950, level: 7, rank: 5 }
  ];

  const mascotMessages = [
    "Great job on your streak! Keep it up!",
    "Ready to tackle some new challenges?",
    "You're doing amazing! Let's learn something new!",
    "Time to level up your skills!",
    "I believe in you! You've got this!"
  ];

  const handleMascotClick = () => {
    playSound('mascot');
    const randomMessage = mascotMessages[Math.floor(Math.random() * mascotMessages.length)];
    setMascotMessage(randomMessage);
  };

  const handleSubjectClick = (subject) => {
    playSound('navigation');
    // Simulate earning XP
    const xpGained = 50;
    setXpPoints(prev => prev + xpGained);
    setShowXPGain(true);
    setTimeout(() => setShowXPGain(false), 2000); // Hide after 2 seconds

    playSound('achievement');
    // Show achievement notification
    setAchievement({
      title: `${subject.name} Progress!`,
      description: `You earned ${xpGained} XP in ${subject.name}!`
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-blue-50 to-teal-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-teal-200 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-navy-900">EduQuest</h1>
              <Badge className="bg-gradient-to-r from-teal-500 to-orange-500 text-white">
                Level {currentLevel}
              </Badge>
            </div>
            
            <div className="flex items-center space-x-6">
              {/* XP Display */}
              <XPCounter xp={xpPoints} animate={true} />
              
              {/* Streak Display */}
              <StreakCounter streak={streak} />
              
              {/* User Avatar */}
              <div className="flex items-center space-x-3">
                <Avatar className="h-10 w-10 border-2 border-teal-500">
                  <AvatarImage src="/api/placeholder/40/40" />
                  <AvatarFallback className="bg-teal-500 text-white">
                    {user?.name?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:block">
                  <p className="font-semibold text-navy-900">{user?.name || 'Student'}</p>
                  <p className="text-sm text-gray-600">Level {currentLevel} Learner</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* XP Gain Effect */}
        <XPGainEffect show={showXPGain} amount={50} position={{ x: window.innerWidth / 2, y: window.innerHeight / 2 }} />

        {/* Achievement Notification */}
        <AchievementNotification 
          achievement={achievement} 
          onClose={() => setAchievement(null)} 
        />
        
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Welcome Section with Mascot */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Card className="bg-gradient-to-r from-teal-500 to-orange-500 text-white border-0 shadow-xl">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h2 className="text-3xl font-bold mb-2">Welcome back, {user?.name || 'Student'}!</h2>
                      <p className="text-xl opacity-90 mb-4">Ready to continue your learning adventure?</p>
                      <div className="flex items-center space-x-4">
                        <div className="bg-white/20 px-4 py-2 rounded-full">
                          <span className="font-semibold">Today's Goal: 200 XP</span>
                        </div>
                        <Progress value={65} className="flex-1 max-w-xs h-3" />
                        <span className="font-semibold">130/200 XP</span>
                      </div>
                    </div>
                    <div className="relative cursor-pointer" onClick={handleMascotClick}>
                      <img 
                        src={mascotFrames[currentMascotFrame]} 
                        alt="EduQuest Mascot" 
                        className="w-32 h-32 object-contain drop-shadow-lg hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute -top-2 -left-4 bg-white text-teal-600 px-3 py-1 rounded-full text-sm font-semibold shadow-lg max-w-xs">
                        {mascotMessage}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Subjects Grid */}
            <div className="grid md:grid-cols-3 gap-6">
              {subjects.map((subject, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-2 hover:border-teal-300"
                        onClick={() => handleSubjectClick(subject)}>
                    <CardHeader className="text-center pb-4">
                      <div className={`mx-auto w-16 h-16 ${subject.color} rounded-full flex items-center justify-center mb-3 shadow-lg`}>
                        <subject.icon className="h-8 w-8 text-white" />
                      </div>
                      <CardTitle className="text-xl font-bold text-navy-900">{subject.name}</CardTitle>
                      <div className="flex justify-center items-center space-x-2">
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                          Level {subject.level}
                        </Badge>
                        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                          {subject.xp} XP
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Progress to Level {subject.level + 1}</span>
                          <span className="font-semibold text-navy-900">{subject.xp}/{subject.nextLevelXp}</span>
                        </div>
                        <Progress value={(subject.xp / subject.nextLevelXp) * 100} className="h-2" />
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm text-gray-700">Recent Badges:</h4>
                        <BadgeCollection badges={subject.badges} maxDisplay={2} />
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm text-gray-700">Continue Learning:</h4>
                        {subject.activities.slice(0, 2).map((activity, i) => (
                          <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                            <span className="text-sm font-medium">{activity}</span>
                            <ChevronRight className="h-4 w-4 text-gray-400" />
                          </div>
                        ))}
                      </div>
                      
                      <Button className="w-full bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700">
                        <Play className="mr-2 h-4 w-4" />
                        Continue Learning
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Achievements */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Trophy className="mr-2 h-5 w-5 text-yellow-500" />
                    Recent Achievements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {recentAchievements.map((achievement, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <achievement.icon className={`h-6 w-6 ${achievement.color}`} />
                      <div className="flex-1">
                        <p className="font-semibold text-sm">{achievement.title}</p>
                        <p className="text-xs text-gray-600">{achievement.description}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </motion.div>

            {/* Leaderboard */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Crown className="mr-2 h-5 w-5 text-yellow-500" />
                    Leaderboard
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {leaderboard.map((player, index) => (
                    <LeaderboardPosition
                      key={index}
                      rank={player.rank}
                      name={player.name}
                      xp={player.xp}
                      isCurrentUser={player.name === 'You'}
                    />
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningPage;


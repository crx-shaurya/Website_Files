import { useState } from 'react'
import LandingPage from './components/LandingPage.jsx'
import AuthPage from './components/AuthPage.jsx'
import LearningPage from './components/LearningPage.jsx'
import './App.css'

function App() {
  const [currentPage, setCurrentPage] = useState('landing')
  const [user, setUser] = useState(null)

  const handleNavigation = (page) => {
    setCurrentPage(page)
  }

  const handleLogin = (userData) => {
    setUser(userData)
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigate={handleNavigation} />
      case 'login':
      case 'register':
        return <AuthPage onNavigate={handleNavigation} onLogin={handleLogin} />
      case 'learning':
        return <LearningPage onNavigate={handleNavigation} user={user} />
      default:
        return <LandingPage onNavigate={handleNavigation} />
    }
  }

  return (
    <div className="App">
      {renderPage()}
    </div>
  )
}

export default App

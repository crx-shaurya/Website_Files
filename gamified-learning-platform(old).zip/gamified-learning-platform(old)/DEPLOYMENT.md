# Deployment Guide for EduQuest

## 🚀 Vercel Deployment (Recommended)

### Method 1: Vercel CLI
1. Install Vercel CLI globally:
   ```bash
   npm install -g vercel
   ```

2. Navigate to your project directory:
   ```bash
   cd gamified-learning-platform
   ```

3. Build the project:
   ```bash
   npm run build
   ```

4. Deploy to Vercel:
   ```bash
   vercel
   ```

5. Follow the prompts:
   - Set up and deploy? **Y**
   - Which scope? Choose your account
   - Link to existing project? **N** (for first deployment)
   - Project name: `eduquest-learning-platform`
   - Directory: `./` (current directory)

### Method 2: Vercel Dashboard
1. Build your project locally:
   ```bash
   npm run build
   ```

2. Go to [vercel.com](https://vercel.com) and sign in
3. Click "New Project"
4. Upload the `dist` folder or connect your Git repository
5. Configure build settings:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

### Method 3: Git Integration
1. Push your code to GitHub/GitLab/Bitbucket
2. Connect your repository to Vercel
3. Vercel will automatically deploy on every push

## 🔧 Build Configuration

### Vite Configuration
The project is already configured for Vercel deployment with:
- Optimized build settings
- Asset optimization
- Static file handling

### Environment Variables
If you add any environment variables later, set them in Vercel dashboard:
1. Go to your project settings
2. Navigate to "Environment Variables"
3. Add your variables

## 📱 Domain Configuration
- Vercel provides a free `.vercel.app` domain
- You can add a custom domain in project settings
- SSL certificates are automatically provided

## 🔍 Troubleshooting

### Common Issues:
1. **Build fails**: Check that all dependencies are in `package.json`
2. **Assets not loading**: Ensure all file paths are relative
3. **Routing issues**: Vercel handles SPA routing automatically

### Performance Optimization:
- Images are already optimized
- CSS is minified in production
- JavaScript is bundled and compressed

## 📊 Monitoring
- Use Vercel Analytics for performance monitoring
- Check deployment logs in Vercel dashboard
- Monitor Core Web Vitals

## 🔄 Updates
To update your deployment:
1. Make changes to your code
2. Push to connected repository (auto-deploy)
   OR
3. Run `vercel --prod` for manual deployment

## 🌐 Alternative Deployment Options

### Netlify
1. Build: `npm run build`
2. Upload `dist` folder to Netlify
3. Configure redirects for SPA routing

### GitHub Pages
1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add to package.json scripts: `"deploy": "gh-pages -d dist"`
3. Run: `npm run deploy`

### Traditional Web Hosting
1. Build: `npm run build`
2. Upload contents of `dist` folder to your web server
3. Configure server for SPA routing

---
**Note**: Vercel is recommended for this project due to its excellent React/Vite support and zero-configuration deployment.

